

<?php $__env->startSection('container'); ?>
   <div class="container">
    <div class="row mb-5">
        <div class="col-lg-8">
            <h1 class="my-3"><?php echo e($kajianstudy->title); ?></h1>

            <a href="/dashboard/kajianstudy" class="btn btn-info"><span data-feather="arrow-left"></span>kembali ke kajian & study saya</a>
            <a href="/dashboard/kajianstudy/<?php echo e($kajianstudy->id); ?>/edit" class="btn btn-warning"><span data-feather="edit"></span> Edit</a>
            <form action="<?php echo e(url('dashboard/kajianstudy/'.$kajianstudy->id)); ?>" method="post" class="d-inline">
                    <?php echo method_field('delete'); ?>
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-danger" onclick="return confirm('Are you sure?')"><span data-feather="x-circle" class="align-text-bottom"></span> Delete</button>
                    </form>
        <div style="max-height: 350px; overflow:hidden;">    
        <img src="<?php echo e(asset('assets/img/kajianstudy/'.$kajianstudy->image)); ?>" class="img-fluid" alt="">
        </div>
        <p><?php echo $kajianstudy->advantage; ?></p>
        <p><?php echo $kajianstudy->body; ?></p>
        </div>
    </div>  
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\bsp-app\resources\views/dashboard/kajianstudy/show.blade.php ENDPATH**/ ?>