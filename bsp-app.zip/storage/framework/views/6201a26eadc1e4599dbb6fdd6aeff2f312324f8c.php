<div class="row" id="data-news">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-4 col-sm-6 mb-4">
        <!-- Portfolio item 1-->
        <div class="portfolio-item" style="max-height: 20%">
            <a class="portfolio-link" data-bs-toggle="modal" href="#portfolioModal1" onclick="showNews(<?php echo e($berita); ?>)">
                <div class="portfolio-hover">
                    <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                </div>
                <img class="img-fluid" src="<?php echo e(asset('assets/img/news/' .$berita->image)); ?>" style="max-width: 100%; max-height:230px" alt="..." />
            </a>
            <div class="portfolio-caption">
                <div class="portfolio-caption-heading"><?php echo $berita->title; ?></div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="pagination-container" style="display: flex; justify-content: flex-end; align-items: center;">
    <?php echo e($data->links()); ?>

    </div>
</div><?php /**PATH D:\LARAVEL\bsp-app\resources\views/livewire/news-list.blade.php ENDPATH**/ ?>