<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
    <div class="container">
        <a class="navbar-brand" href="#page-top"><img src="<?php echo e(asset('assets/img/logo-bsp-transparan.png')); ?>" alt="..." height="150px" /></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            Menu
            <i class="fas fa-bars ms-1"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav text-uppercase ms-auto py-4 py-lg-0">
                
                <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/#about')); ?>">Tentang Kami</a></li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="/services" aria-expanded="false">Pelatihan</a>
                    <ul class="dropdown-menu" style="max-height: 200px; overflow-y: auto;">
                        <?php $__currentLoopData = $training; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a class="dropdown-item" href="/pelatihan/<?php echo e($row->id); ?>"><?php echo e($row->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="/services" aria-expanded="false">Konsultasi</a>
                    <ul class="dropdown-menu" style="max-height: 200px; overflow-y: auto;">
                        <?php $__currentLoopData = $consultation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a class="dropdown-item" href="/konsultasi/<?php echo e($row->id); ?>"><?php echo e($row->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="/services" aria-expanded="false"> Auditing </a>
                    <ul class="dropdown-menu" style="max-height: 200px; overflow-y: auto;">
                        <?php $__currentLoopData = $auditing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a class="dropdown-item" href="/auditing/<?php echo e($row->id); ?>"><?php echo e($row->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="/services" aria-expanded="false"> Bimtek </a>
                    <ul class="dropdown-menu" style="max-height: 200px; overflow-y: auto;">
                        <?php $__currentLoopData = $bimtek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a class="dropdown-item" href="/bimtek/<?php echo e($row->id); ?>"><?php echo e($row->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="/services" aria-expanded="false"> Kajian & Study </a>
                    <ul class="dropdown-menu" style="max-height: 200px; overflow-y: auto;">
                        <?php $__currentLoopData = $kajianstudy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a class="dropdown-item" href="/kajianstudy/<?php echo e($row->id); ?>"><?php echo e($row->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/#portfolio')); ?>">Berita</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/#team')); ?>">Klien</a></li>
                <li class="nav-item"><a class="nav-link" href="#contact">Hubungi Kami</a></li>
            </ul>
                </div>
            </div>
        </nav><?php /**PATH D:\LARAVEL\bsp-app\resources\views/partials/navbar.blade.php ENDPATH**/ ?>