

<?php $__env->startSection('container'); ?>
   <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Edit Kajian & Study</h1>
      </div>

      <div class="col-lg-8">
          <form method="post" action="<?php echo e(url('dashboard/kajianstudy/'.$kajianstudy->id)); ?>" enctype="multipart/form-data">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
              <div class="mb-3">
                  <label for="title" class="form-label">Title</label>
                  <input type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="title" name="title" required autofocus value="<?php echo e(old("title",$kajianstudy->title)); ?>">
                  <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div> 
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              <div class="mb-3">
                  <label for="title" class="form-label">Sub Title</label>
                  <input type="text" class="form-control <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="subtitle" name="subtitle" autofocus value="<?php echo e(old("subtitle",$kajianstudy->subtitle)); ?>">
                  <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div> 
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3">
                  <label for="image" class="form-label">Upload Foto</label>
                  <input type="hidden" name="oldImage" value="<?php echo e($kajianstudy->image); ?>">
                  <input class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="image" name="image">
                  <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div> 
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3">
                  <label for="image_brosur" class="form-label">Upload Foto Brosur</label>
                  <input type="hidden" name="oldImageBrosur" value="<?php echo e($kajianstudy->image_brosur); ?>">
                  <input class="form-control <?php $__errorArgs = ['image_brosur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="image_brosur" name="image_brosur">
                  <?php $__errorArgs = ['image_brosur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div> 
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              <div class="mb-3">
                  <label for="category" class="form-label">Manfaat</label>
                    <input id="advantage" type="hidden" name="advantage" value="<?php echo e(old('advantage',$kajianstudy->advantage)); ?>">
                    <trix-editor input="advantage"></trix-editor>
                </div>
              <div class="mb-3">
                  <label for="category" class="form-label">Deskripsi</label>
                    <input id="body" type="hidden" name="body" value="<?php echo e(old('body',$kajianstudy->body)); ?>">
                    <trix-editor input="body"></trix-editor>
              </div>
              <div class="mb-3">
                  <label for="paket" class="form-label">Paket Kajian & Study</label>
                    <input id="paket" type="hidden" name="paket" value="<?php echo e(old('paket',$kajianstudy->paket)); ?>">
                    <trix-editor input="paket"></trix-editor>
              </div>
              <button type="submit" class="btn btn-primary">Submit</button>
          </form>
      </div>

      <script>
          // const title = document.querySelector('#title');
          // const slug = document.querySelector('#slug');

          // title.addEventListener('change', function(){
          //     fetch('/dashboard/post/checkSlug?title=' + title.value)
          //     .then(response => response.json())
          //     .then(data => slug.value = data.slug)
          // });

          document.addEventListener('trix-file-accept', function(e){
              e.preventDefault();
          })

      </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bina1108/public_html/resources/views/dashboard/kajianstudy/edit.blade.php ENDPATH**/ ?>