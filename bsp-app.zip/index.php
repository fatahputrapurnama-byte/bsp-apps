<?php

header('Location: public/');