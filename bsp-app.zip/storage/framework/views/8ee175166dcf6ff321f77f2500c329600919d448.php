        <!-- Navigation-->
        
        <!-- Masthead-->
        

        <?php $__env->startSection('container'); ?>
        <header class="masthead" style="background-image: url('../assets/img/header-bg.jpg');">
            <div class="container">
                <img src="<?php echo e(asset('assets/img/logo-bsp-transparan.png')); ?>" style="margin: 10px;" alt="logo-bsp">
                <div class="masthead-heading text-uppercase">BINA SOLUSI PURNAMA</div>
                <div class="masthead-subheading">ENGINEERING & MANAGEMENT CONSULTANT</div>
                <a class="btn btn-primary btn-xl text-uppercase" href="#about" style="margin: 10px">Learn More</a>
                <a class="btn btn-primary btn-xl text-uppercase" href="#contact">Contact Us</a>
            </div>
        </header>
        <!-- Services-->
        
        <!-- Portfolio Grid-->
        <section class="page-section bg-light" id="portfolio">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Berita</h2>
                    
                </div>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('news-list')->html();
} elseif ($_instance->childHasBeenRendered('oNpelS5')) {
    $componentId = $_instance->getRenderedChildComponentId('oNpelS5');
    $componentTag = $_instance->getRenderedChildComponentTagName('oNpelS5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('oNpelS5');
} else {
    $response = \Livewire\Livewire::mount('news-list');
    $html = $response->html();
    $_instance->logRenderedChild('oNpelS5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                
            </div>
        </section>
        <!-- About-->
        <section class="page-section" id="about">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">TENTANG BINA SOLUSI PURNAMA</h2>
                    
                </div>
                <div class="text-center">
                    <img src="<?php echo e(asset('assets/img/logo-bsp-transparan.png')); ?>" alt="logo-bsp"><br><br>
                    <p><strong><h4>LATAR BELAKANG PERUSAHAAN</h4></strong></p>
                    <p align="justify"> Bina Solusi Purnama merupakan konsultan dalam bidang manajemen dan teknik, Pada awalnya kami hanya menggeluti konsultan Manajemen perorangan bersekala kecil, yaitu perancangan sistem pengelolaan yang ada di perusahaan mulai Sistem Manajemen Mutu, Sistem Manajemen Lingkungan, Sistem Manajemen Keselamatan dan Kesehatan Kerja, Sistem Manajemen Laboratorium, Sistem Inventory, Produksi, Engineering, PPIC, Quality Control, dan Pemeliharaan. Pada tahun 2012 kami meresmikan perusahaan sebagai perusahaan konsultan dalam bidang manajemen dan     teknik     dalam     bentuk     Persekutuan     Komanditer     /     Commanditaire Vennootschap (CV) dengan Akte Notaris Cecilia Sri Barlejanti SH, No 01 tanggal 01 Maret 2012. Seiring dengan perkembangan usaha, pada tahun 2018 kami merubah bentuk badan hukum usaha menjadi Perusahaan Terbatas (PT) dengan akta notaris H.  Iwan  Yusuf  Anwari,  S.H,  No.  19  tanggal  17  Desember  2018  dan  Keputusan Menteri Hukum dan HAM Republik Indonesia Nomor AHU-0061417.AH.01.01. Tahun 2018 Tentang Pengesahan Pendirian Badan Hukum Perseroan Terbatas PT. Bina Solusi Purnama tanggal 21 Desember 2018.</p>
                    <p align="justify"> Perusahaan kami bergerak dalam bidang manajemen dan teknik, yaitu kami menyediakan jasa konsultasi terkait : ISO 9001 Sistem Manajemen Mutu, ISO 17025 untuk Laboratorium, ISO 17020 untuk Lembaga Inspeksi, ISO 14001 untuk lingkungan, OHSAS 18001/ISO 45000 Sistem Manajemen Kesehatan Dan Keselamatan  Kerja,  ISO  22000  Sistem  Manajemen  Keamanan  Pangan,  ISO  21001 Sistem Manajemen Organisasi Pendidikan, ISO 37001 Sistem Manajemen Anti Penyuapan, ISO 31000 Manajemen Risiko, Standar Operasional Prosedur (SOP), Manajemen  Produksi, Manajemen Logistik, Perencanaan Transportasi, Perancangan Tata Letak Fasilitas/Pabrik Serta Perencanaan Wilayah dan Kota Dengan tenaga ahli yang professional dan berpengalaman, kami berkomitmen untuk memberikan jasa konsultasi pengembangan sistem manajemen yang mudah digunakan oleh organisasi dan  untuk meningkatkan pelayanan yang bukan hanya dibangun atas kepentingan bisnis semata tetapi juga memiliki akar pada hubungan baik serta kepuasan konsumen.</p>
                    <p align="justify"> Atas dasar hal itulah kami akan berusaha untuk memberikan yang terbaik dan lebih dari biasanya untuk menciptakan kenyamanan baru bagi konsumen mempercepat, mempermudah pelayanan serta memberikan informasi kepada konsumen yang pada akhirnya akan menggugah atensi konsumen pada organisasi.</p>
                    <p><strong><h4>STRUKTUR ORGANISASI</h4></strong></p>
                    <img src="<?php echo e(asset('assets/img/struktur-organisasi.png')); ?>" alt="logo-bsp" style="max-width: 100%">
                </div>
                
            </div>
        </section>
        <!-- Team-->
        <section class="page-section bg-light" id="team">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Klien</h2>
                    
                </div>
                <div class="row">
                    <!-- Slider main container -->
                    <div class="swiper">
                    <!-- Additional required wrapper -->
                    <div class="swiper-wrapper">
                        <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Slides -->
                        <div class="swiper-slide">
                            <div style="max-height: 100px">
                                <img class="mx-auto" src="<?php echo e(asset('assets/img/client/' .$post->image)); ?>" alt="..." style="max-width: 100%; max-height:230px"/>
                                
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- If we need pagination -->
                    <div class="swiper-pagination"></div>

                    <!-- If we need navigation buttons -->
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-button-next"></div>

                    <!-- If we need scrollbar -->
                    
                    </div>
                </div>
                
            </div>
        </section>
        <!-- Contact-->
        <section class="page-section" id="contact">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Hubungi Kami</h2>
                </div>
                <!-- * * * * * * * * * * * * * * *-->
                <!-- * * SB Forms Contact Form * *-->
                <!-- * * * * * * * * * * * * * * *-->
                <!-- This form is pre-integrated with SB Forms.-->
                <!-- To make this form functional, sign up at-->
                <!-- https://startbootstrap.com/solution/contact-forms-->
                <!-- to get an API token!-->
                <form id="contactForm">
                    <div class="row align-items-stretch mb-5">
                        <div class="col-md-6">
                            <div class="form-group">
                                <!-- Name input-->
                                <input class="form-control" oninput="validasi()" name="name" id="name" type="text" placeholder="Your Name *" required/>
                                <div class="invalid-feedback">A name is required.</div>
                            </div>
                            <div class="form-group">
                                <!-- Email address input-->
                                <input class="form-control" oninput="validasi()" name="email" id="email" type="email" placeholder="Your Email *" required />
                            </div>
                            <div class="form-group mb-md-0">
                                <!-- Phone number input-->
                                <input class="form-control" oninput="validasi()" name="phone" id="phone" type="tel" placeholder="Your Phone *" required/>
                                <div class="invalid-feedback">A phone number is required.</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group form-group-textarea mb-md-0">
                                <!-- Message input-->
                                <textarea class="form-control" oninput="validasi()" name="message" id="message" placeholder="Your Message *" required></textarea>
                                <div class="invalid-feedback">A message is required.</div>
                            </div>
                        </div>
                    </div>
                    <!-- Submit success message-->
                    <!---->
                    <!-- This is what your users will see when the form-->
                    <!-- has successfully submitted-->
                    <div style="display: none" id="submitSuccessMessage">
                        <div class="text-center text-white mb-3">
                            <div class="fw-bolder">Berhasil</div>
                        </div>
                    </div>
                    <!-- Submit error message-->
                    <!---->
                    <!-- This is what your users will see when there is-->
                    <!-- an error submitting the form-->
                    <div class="d-none" id="submitErrorMessage"><div class="text-center text-danger mb-3">Error sending message!</div></div>
                    <!-- Submit Button-->
                    <div class="text-center"><button class="btn btn-primary btn-xl text-uppercase" disabled id="submitButton" type="submit">Send Message</button></div>
                </form>
            </div>
        </section>
        <!-- Portfolio Modals-->
        <!-- Portfolio item 1 modal popup-->
        <div class="portfolio-modal modal fade" id="portfolioModal1" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="close-modal" data-bs-dismiss="modal"><img src="assets/img/close-icon.svg" alt="Close modal" /></div>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="modal-body">
                                    <!-- Project details-->
                                    <h2 class="text-uppercase" id="title-news"></h2>
                                    <img id="img-news" class="img-fluid d-block mx-auto" src="" alt="..." />
                                    <p id="body-news" style="text-align: justify"></p>
                                    <button class="btn btn-primary btn-xl text-uppercase" data-bs-dismiss="modal" type="button">
                                        <i class="fas fa-xmark me-1"></i>
                                        Close
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Portfolio item 2 modal popup-->
        
        <a href="https://api.whatsapp.com/send?phone=62895396858094&amp;text=Saya%20ingin%20tahu%20lebih%20lanjut%20tentang%20layanan%20dari%20Bina%20Solusi%20Purnama" class="mad_button" target="_blank" style="position:fixed; right:50px; bottom:50px; z-index:9999;"><img src="<?php echo e(asset('assets/wa.png')); ?>" alt="wa" style="max-height: 70px;"></a>
        
        <style>
            .swiper {
                width: 100%;
                height: 350px;
                }
        </style>
        
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('script'); ?>
        <script>
            const swiper = new Swiper('.swiper', {
                // Optional parameters
                direction: 'horizontal',
                slidesPerView: 3, // Menampilkan 3 slide sekaligus
                spaceBetween: 30,
                loop: true,

                // If we need pagination
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                },

                // Navigation arrows
                navigation: {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev',
                },

                // And if we need scrollbar
                // scrollbar: {
                //     el: '.swiper-scrollbar',
                //     draggable: true,
                // },
            });

            function showNews(news){
                // console.log(news);
                $('#title-news').text(news.title);
                // $('#body-news').text(news.body);
                document.getElementById('body-news').innerHTML = news.body;
                $('#img-news').attr('src', "<?php echo e(asset('assets/img/news/')); ?>" + '/' + news.image);
            }

            // $("#portfolio .page-link").on('click', function(event){
            //     // event.stopPropagation();
            //     // event.stopImmediatePropagation();
            //     event.preventDefault();
            //     // console.log(event.target.href);
            //     // window.location.href = event.target.href + "#portfolio";
            //     var url = "/data";
            //     getPageNews(url);
            //     //(... rest of your JS code)
            // });

            // function getPageNews(url) {
            //     $.ajaxSetup({
            //     headers: {
            //         'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            //     }
            //     });
            //     $.ajax({
            //         url: url,
            //         type: 'GET',
            //         dataType: 'json',
            //         success: function(response) {
            //             console.log(response)
            //             $('#data-news').html($(response).find('#data-news').html());
            //             $('#pagination-news').html($(response).find('#pagination-news').html());
            //         },
            //         error: function(err){
            //             console.log(err)
            //         }
            //     });
            // }

            // $("#team .page-link").on('click', function(event){
            //     // event.stopPropagation();
            //     // event.stopImmediatePropagation();
            //     event.preventDefault();
            //     console.log(event.target.href);
            //     window.location.href = event.target.href + "#team";
            //     //(... rest of your JS code)
            // });

            function validasi(){
                var name = $('#name').val();
                var email = $('#email').val();
                var no_hp = $('#phone').val();
                var pesan = $('#message').val();

                if (name && email && no_hp && pesan) {
                    $('#submitButton').prop('disabled', false);
                }
            }
            
            $("#contactForm").submit(function(e){
                e.preventDefault();
                contact();
            });

            function contact(){
                $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
                });
                $.ajax({
                    type:'POST',
                    url:"<?php echo e(route('contact')); ?>",
                    data:{
                        name: $('#name').val(),
                        email: $('#email').val(),
                        no_hp: $('#phone').val(),
                        pesan: $('#message').val()
                    },
                    success:function(data) {
                        $('#submitSuccessMessage').show();
                        $('#name').val('');
                        $('#email').val('');
                        $('#phone').val('');
                        $('#message').val('');
                    },
                    error: function(err) {
                        // console.log(err)
                        alert("Gagal!");
                    }
                });
            }
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\bsp-app\resources\views/landing/index.blade.php ENDPATH**/ ?>