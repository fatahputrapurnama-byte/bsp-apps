

<?php $__env->startSection('container'); ?>
   <div class="container">
    <div class="row mb-5">
        <div class="col-lg-8">
            <h1 class="my-3"><?php echo e($consultation->title); ?></h1>

            <a href="/dashboard/konsultasi" class="btn btn-info"><span data-feather="arrow-left"></span>kembali ke konsultasi saya</a>
            <a href="/dashboard/konsultasi/<?php echo e($consultation->id); ?>/edit" class="btn btn-warning"><span data-feather="edit"></span> Edit</a>
            <form action="<?php echo e(url('dashboard/konsultasi/'.$consultation->id)); ?>" method="post" class="d-inline">
                    <?php echo method_field('delete'); ?>
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-danger" onclick="return confirm('Are you sure?')"><span data-feather="x-circle" class="align-text-bottom"></span> Delete</button>
                    </form>
        <div style="max-height: 350px; overflow:hidden;">    
        <img src="<?php echo e(asset('assets/img/konsultasi/'.$consultation->image)); ?>" class="img-fluid" alt="">
        </div>
        <p><?php echo $consultation->advantage; ?></p>
        <p><?php echo $consultation->body; ?></p>
        </div>
    </div>  
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\bsp-app\resources\views/dashboard/konsultasi/show.blade.php ENDPATH**/ ?>