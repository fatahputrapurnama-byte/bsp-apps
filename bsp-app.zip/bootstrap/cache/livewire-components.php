<?php return array (
  'news-list' => 'App\\Http\\Livewire\\NewsList',
);