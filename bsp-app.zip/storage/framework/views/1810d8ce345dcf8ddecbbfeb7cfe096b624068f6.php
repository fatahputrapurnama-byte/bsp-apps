

<?php $__env->startSection('container'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">List pengunjung</h1>
      </div>
      <?php if(session()->has('success')): ?> 
        <div class="alert alert-success alert-dismissible fade show col-lg-8" role="alert">
        <strong><?php echo e(session('success')); ?></strong>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
      <?php endif; ?>
      <div class="table-responsive col-lg-8">
        
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Nama</th>
              <th scope="col">Email</th>
              <th scope="col">No Hp</th>
              <th scope="col">Status</th>
            </tr>
          </thead>
          <tbody>
              <?php $__currentLoopData = $contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($post->name); ?></td>
                <td><?php echo e($post->email); ?></td>
                <td><?php echo e($post->no_hp); ?></td>
                
                <td>
                <?php if($post->hubungi === 1): ?>    
                <button class="badge bg-success border-0" disabled>Sudah dihubungi</button>
                <?php else: ?>
                <form method="post" action="<?php echo e(url('dashboard/contact/'.$post->id)); ?>" class="d-inline">
                  <?php echo method_field('put'); ?>
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="hubungi" id="hubungi" value="1">
                  <button class="badge bg-danger border-0">Belum dihubungi</button>
                </form>
                <?php endif; ?>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <?php echo e($contact->links()); ?>

      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\bsp-app\resources\views/dashboard/contact/index.blade.php ENDPATH**/ ?>